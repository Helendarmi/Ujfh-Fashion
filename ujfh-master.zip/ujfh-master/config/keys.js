module.exports = {
  mongoURI: 'mongodb://neto1:netoneto1@ds217921.mlab.com:17921/ujfashion',
  mongoURL: 'mongodb://localhost:27017/ujfashion',
  secretkey: 'psidob'
};
